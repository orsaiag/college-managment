package college_managment_system;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException, CloneNotSupportedException {
		View.loginView();

	}

}
